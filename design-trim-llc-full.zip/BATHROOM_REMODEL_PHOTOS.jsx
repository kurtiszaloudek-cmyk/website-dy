// Bathroom Remodel Photo List (fixed)
// - Removed any stray characters after console.error
// - Kept existing entries and the 8 new photos
// - Exported the array for use elsewhere in the app
// - Added extra runtime checks to prevent future data mistakes

export const BATHROOM_REMODEL_PHOTOS = [
  { title: "Bathroom remodel – vanity & trim", sources: ["/images/4600.jpg"] },
  { title: "Bathroom remodel – shower install", sources: ["/images/4601.jpg"] },
  { title: "Bathroom remodel – light & ceiling detail", sources: ["/images/bathroom_1.jpg"] },
  { title: "Bathroom remodel – ceiling pine planks", sources: ["/images/bathroom_2.jpg"] },
  { title: "Bathroom remodel – full view", sources: ["/images/bathroom_3.jpg"] },
  { title: "Bathroom remodel – new shower tile", sources: ["/images/bathroom_4.jpg"] },
  { title: "Bathroom remodel – vanity & tile detail", sources: ["/images/bathroom_5.jpg"] },
  { title: "Bathroom remodel – new tile flooring", sources: ["/images/bathroom_6.jpg"] },
  { title: "Bathroom remodel – modern black fixtures", sources: ["/images/bathroom_7.jpg"] },
  { title: "Bathroom remodel – sink & faucet update", sources: ["/images/bathroom_8.jpg"] }
];

// -----------------------------
// Lightweight Runtime Tests
// -----------------------------
// These run in dev/runtime and help ensure we don't introduce formatting mistakes again.
(function runBathroomPhotoTests() {
  try {
    // Test 1: Array exists & has at least 10 items
    console.assert(Array.isArray(BATHROOM_REMODEL_PHOTOS), "BATHROOM_REMODEL_PHOTOS must be an array");
    console.assert(BATHROOM_REMODEL_PHOTOS.length >= 10, "Expected at least 10 bathroom photos");

    // Test 2: Every entry has a non-empty title and sources array of strings
    for (const [idx, it] of BATHROOM_REMODEL_PHOTOS.entries()) {
      console.assert(typeof it.title === "string" && it.title.trim().length > 0, `Photo[${idx}] missing valid title`);
      console.assert(Array.isArray(it.sources) && it.sources.length > 0, `Photo[${idx}] missing sources`);
      console.assert(it.sources.every((s) => typeof s === "string" && s.trim().length > 0), `Photo[${idx}] sources must be strings`);
    }

    // Test 3: Known files included (spot-check a couple of new ones)
    const paths = BATHROOM_REMODEL_PHOTOS.flatMap((p) => p.sources);
    console.assert(paths.includes("/images/bathroom_6.jpg"), "New tile flooring image missing");
    console.assert(paths.includes("/images/bathroom_8.jpg"), "Sink & faucet update image missing");

    // Test 4: All paths are in /images/ (helps catch typos)
    console.assert(paths.every(p => p.startsWith("/images/")), "All bathroom images should live under /images/");

    // Test 5: Titles are unique (avoids duplicate keys in render)
    const titleSet = new Set(BATHROOM_REMODEL_PHOTOS.map(p => p.title));
    console.assert(titleSet.size === BATHROOM_REMODEL_PHOTOS.length, "Bathroom photo titles should be unique");
  } catch (err) {
    // Don't crash the app; surface in console for quick debugging
    console.error("Bathroom photo tests failed:", err);
  }
})();