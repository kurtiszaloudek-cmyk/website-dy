
# Design Trim LLC — Website

Vite + React + Tailwind. No external icon libraries. Images live in `/public/images`.

## Local Dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy to Vercel
1. Create a new Vercel project, **Import** from your repo or **Deploy** from ZIP.
2. Framework preset: **Vite** (or just default).
3. Build Command: `vite build`
4. Output Directory: `dist`
5. Root directory: project root (where `package.json` is).

## Notes
- Phone: (913) 755-1550 (tap-to-call & tap-to-text enabled)
- Email: designtimllc@gmail.com
- Service Area: Johnson County, KS
- Services route to Portfolio with hash: `#portfolio:Category`
