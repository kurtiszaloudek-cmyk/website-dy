import React, { useEffect, useRef, useState } from "react";

// =====================================================
// Design Trim LLC – One-page Website (React + Tailwind)
// =====================================================
// Notes:
// - No external icon libs required; inline SVG is used.
// - Services -> Portfolio uses hash routing with temporary chip highlight.
// - Tap-to-call & tap-to-text enabled via tel:/sms: links.
// - No Facebook/Instagram anywhere.
// - Keep images under /images/ in your hosting (Vercel public/ folder).

// -----------------------------
// Helpers (exported for tests)
// -----------------------------
export function sanitizeDigits(str: string){ return String(str).replace(/\D/g, ""); }
export function nextIndex(curr: number, len: number){ return (curr + 1) % len; }
export function prevIndex(curr: number, len: number){ return (curr - 1 + len) % len; }

// -----------------------------
// Safe image component (tries fallbacks)
// -----------------------------
function SafeImg({ sources, alt, className }: { sources: string | string[]; alt?: string; className?: string }){
  const list = Array.isArray(sources) ? sources : [sources];
  const [i, setI] = useState(0);
  return (
    <img
      src={list[Math.min(i, list.length - 1)]}
      alt={alt}
      className={className}
      loading="lazy"
      onError={() => setI(n => (n < list.length - 1 ? n + 1 : n))}
    />
  );
}

// -----------------------------
// Business info
// -----------------------------
const BUSINESS = {
  name: "Design Trim LLC",
  tagline: "Precision Finish Carpentry & Custom Trim Work",
  phone: "(913) 755-1550",
  email: "designtimllc@gmail.com",
  location: "Johnson County, KS",
};

// -----------------------------
// Inline Icons
// -----------------------------
const Svg = ({ children, className }: any) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
    {children}
  </svg>
);
const IconChevronLeft = (p:any)=>(<Svg {...p}><path d="M15 19 8 12l7-7"/></Svg>);
const IconChevronRight = (p:any)=>(<Svg {...p}><path d="m9 5 7 7-7 7"/></Svg>);
const IconPhone = (p:any)=>(<Svg {...p}><path d="M22 16.92v2a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.92 4.18 2 2 0 0 1 4.92 2h2a2 2 0 0 1 2 1.72c.12.88.33 1.73.62 2.54a2 2 0  0 1-.45 2.11L8.09 9.37a16 16 0  0 0 6.54 6.54l1-1.02a2 2 0  0 1 2.1-.45c.81.29 1.66.5 2.54.62A2 2 0  0 1 22 16.92z"/></Svg>);
const IconMail = (p:any)=>(<Svg {...p}><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0  0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="m22 6-10 7L2 6"/></Svg>);
const IconMapPin = (p:any)=>(<Svg {...p}><path d="M12 21s7-4.35 7-10a7 7 0 1 0-14 0c0 5.65 7 10 7 10z"/><circle cx="12" cy="11" r="3"/></Svg>);
const IconStar = (p:any)=>(<Svg {...p}><path d="m12 2 3.09 6.26 6.91 1-5 4.87 1.18 6.87L12 18l-6.18 3 1.18-6.87-5-4.87 6.91-1L12 2z"/></Svg>);
const IconMessage = (p:any)=>(<Svg {...p}><path d="M21 15a4 4 0  0 1-4 4H8l-5 3V7a4 4 0  0 1 4-4h10a4 4 0  0 1 4 4z"/></Svg>);
const IconShield = (p:any)=>(<Svg {...p}><path d="M12 22s8-4 8-10V6l-8-4-8 4v6c0 6 8 10 8 10"/><path d="M9 12l2 2 4-4"/></Svg>);

// -----------------------------
// Image data
// -----------------------------
const HERO_IMAGES = [
  "https://images.unsplash.com/photo-1519710164239-da123dc03ef4?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1556909212-d5cd3f37f4dc?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1582582621959-48a94f6b2b41?q=80&w=1600&auto=format&fit=crop",
];

// Windows & Doors
const WINDOWS_DOORS = [
  { title: "Patio French doors – new casing", sources: ["/images/IMG_20230405_101114.jpg"] },
  { title: "Exterior window trim – prep & masking", sources: ["/images/PXL_20250527_213421343.MP.jpg"] },
  { title: "Bathroom window – new unit & casing", sources: ["/images/PXL_20250620_181917259.jpg"] },
  { title: "Laundry window – interior casing", sources: ["/images/PXL_20250815_195310097.jpg"] },
  { title: "Shower privacy window – frosted glass with trim", sources: ["/images/PXL_20250815_201706766.jpg"] },
  { title: "Interior door – casing & paint", sources: ["/images/PXL_20250820_132611191.jpg"] },
  { title: "Breakfast nook windows – bench & casing", sources: ["/images/4339.jpg"] },
];

// Crown Molding
const CROWN_MOLDING = [
  { title: "Cabinet top cap & crown – inside corner", sources: ["/images/PXL_20250207_222303445.jpg"] },
  { title: "Crown return at cabinet end", sources: ["/images/PXL_20250207_222256111.jpg"] },
  { title: "Crown run across soffit", sources: ["/images/PXL_20250207_222250473.jpg"] },
];

// Cabinets & Built-ins
const CABINET_PHOTOS = [
  { title: "Kitchen cabinet install – island framing", sources: ["/images/PXL_20250129_215524910.jpg"] },
  { title: "Small kitchen – new pre-built cabinets", sources: ["/images/PXL_20240806_205334505.jpg"] },
  { title: "Living room built-in – base cabinet run", sources: ["/images/PXL_20250129_215618258.jpg"] },
  { title: "Kitchen uppers with custom hood valance", sources: ["/images/PXL_20250130_212604573.jpg"] },
  { title: "Pantry/utility cabinetry – install phase", sources: ["/images/PXL_20250129_215530925(1).jpg"] },
  { title: "Commercial built-ins – storage wall", sources: ["/images/PXL_20241121_184048010(1).jpg"] },
  { title: "Bay window bench – cabinet bases", sources: ["/images/PXL_20250129_215600692.jpg"] },
];

// Barn Doors
const BARN_DOOR_PHOTOS = [
  { title: "Custom stained barn door with hardware", sources: ["/images/4344.jpg"] },
  { title: "Barn door track install – drywall phase", sources: ["/images/IMG_20250504_111212.jpg"] },
  { title: "Barn door – raw pine install", sources: ["/images/4598.jpg"] },
];

// Fire Mantels
const FIRE_MANTEL_PHOTOS = [
  { title: "Custom fireplace mantel", sources: ["/images/4523.jpg"] },
];

// Bathroom Remodels (using the actual filenames you uploaded)
export const BATHROOM_REMODEL_PHOTOS = [
  { title: "Bathroom remodel – vanity & trim", sources: ["/images/4600.jpg"] },
  { title: "Bathroom remodel – shower install", sources: ["/images/4601.jpg"] },
  { title: "Pine plank ceiling with crown", sources: ["/images/IMG_20250219_174423.jpg"] },
  { title: "Completed bath – vanity, tile, trim", sources: ["/images/IMG_20250219_174443.jpg"] },
  { title: "Tile floor close-up", sources: ["/images/IMG_20250219_231035.jpg"] },
  { title: "Towel niche & surround", sources: ["/images/IMG_20250219_220001.jpg"] },
  { title: "Tub/shower surround complete", sources: ["/images/IMG_20250219_220017.jpg"] },
  { title: "Vanity & lighting", sources: ["/images/IMG_20250219_220203.jpg"] },
  { title: "Vanity corner detail", sources: ["/images/IMG_20250219_220214.jpg"] },
];

// Baseboards
const BASEBOARD_PHOTOS = [
  { title: "Office baseboard – outside corner miter", sources: ["/images/PXL_20240807_200611635.jpg"] },
  { title: "Baseboard run with doorway transition", sources: ["/images/PXL_20240807_200559136.jpg"] },
  { title: "Baseboard install – prep and cove", sources: ["/images/Img_1723061784914_6660795713769698415.png"] },
  { title: "Baseboard at polished concrete edge", sources: ["/images/Img_1723061798524_8339812331680398385.png"] },
];

// Staircases
const STAIR_PHOTOS = [
  { title: "Basement stair balustrade refresh", sources: ["/images/FB_IMG_1755745609143.jpg"] },
  { title: "Iron balusters on carpeted stairs", sources: ["/images/FB_IMG_1755745807175.jpg"] },
  { title: "Two-story grid wall with stair rail", sources: ["/images/FB_IMG_1755744714261.jpg"] },
  { title: "Basement stair update", sources: ["/images/FB_IMG_1755745513139.jpg"] },
  { title: "Multi-landing staircase with newels", sources: ["/images/FB_IMG_1755745646973.jpg"] },
  { title: "Iron balusters details", sources: ["/images/FB_IMG_1755744382847.jpg"] },
  { title: "Overlook railing with iron spindles", sources: ["/images/FB_IMG_1755744725576.jpg"] },
  { title: "Feature wall and stair flight", sources: ["/images/FB_IMG_1755744731153.jpg"] },
  { title: "Landing railing detail", sources: ["/images/FB_IMG_1755744366410.jpg"] },
];

// Wainscoting
const WAINS_PHOTOS = [
  { title: "Two-story foyer – board & batten layout", sources: ["/images/1000003234.jpg"] },
  { title: "Geometric accent wall – painted finish", sources: ["/images/715912157.jpg"] },
];

// -----------------------------
// UI building blocks
// -----------------------------
function SectionTitle({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }){
  return (
    <div className="max-w-3xl mx-auto text-center mb-12">
      {eyebrow && (<p className="uppercase tracking-widest text-xs font-semibold text-gray-400 mb-2">{eyebrow}</p>)}
      <h2 className="text-3xl md:text-4xl font-semibold text-gray-100">{title}</h2>
      {subtitle && <p className="text-gray-400 mt-3">{subtitle}</p>}
    </div>
  );
}

function Nav(){
  const links=[
    { href: "#services", label: "Services" },
    { href: "#portfolio", label: "Portfolio" },
    { href: "#about", label: "About" },
    { href: "#reviews", label: "Reviews" },
    { href: "#contact", label: "Contact" },
  ];
  return (
    <nav className="fixed top-0 inset-x-0 z-50 backdrop-blur bg-neutral-900/70 border-b border-white/5" aria-label="Main">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <a href="#home" className="text-lg font-semibold tracking-tight text-white">{BUSINESS.name}</a>
        <div className="hidden md:flex items-center gap-6">
          {links.map(l => (<a key={l.href} href={l.href} className="text-sm text-gray-300 hover:text-white">{l.label}</a>))}
          <a href="#contact" className="px-3 py-2 rounded-2xl bg-emerald-500/90 hover:bg-emerald-500 text-white text-sm shadow">Get a Quote</a>
        </div>
      </div>
    </nav>
  );
}

function Hero(){
  const [idx,setIdx]=useState(0);
  const next=()=>setIdx(i=>nextIndex(i,HERO_IMAGES.length));
  const prev=()=>setIdx(i=>prevIndex(i,HERO_IMAGES.length));
  return (
    <section id="home" className="relative pt-16">
      <div className="relative h-[70vh] md:h-[80vh] overflow-hidden rounded-b-[2rem]">
        <img key={idx} src={HERO_IMAGES[idx]} alt="Showcase of trim work" className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500"/>
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/20 to-transparent"/>
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-6xl mx-auto px-4 pb-10 w-full">
            <div className="max-w-2xl">
              <h1 className="text-4xl md:text-6xl font-semibold text-white">{BUSINESS.tagline}</h1>
              <p className="text-gray-300 mt-4 text-lg">Custom crown molding, wainscoting, built-ins, and finish carpentry — done right the first time.</p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <a href="#contact" className="px-5 py-3 rounded-2xl bg-emerald-500 text-white shadow hover:bg-emerald-500/90">Request a Free Estimate</a>
                <a href={`tel:${sanitizeDigits(BUSINESS.phone)}`} className="px-5 py-3 rounded-2xl border border-white/10 text-white hover:bg-white/5"><span className="inline-flex items-center gap-2"><IconPhone className="w-5 h-5"/> Call {BUSINESS.phone}</span></a>
                <a href={`sms:${sanitizeDigits(BUSINESS.phone)}`} className="px-5 py-3 rounded-2xl border border-white/10 text-white hover:bg-white/5"><span className="inline-flex items-center gap-2"><IconMessage className="w-5 h-5"/> Text Us</span></a>
              </div>
              <div className="mt-6 flex items-center gap-4 text-gray-300">
                <div className="flex items-center gap-2"><IconMapPin className="w-5 h-5"/> {BUSINESS.location}</div>
                <div className="flex items-center gap-2"><IconStar className="w-5 h-5"/> 5.0★ Rated by homeowners</div>
                <div className="flex items-center gap-2"><IconShield className="w-5 h-5"/> Licensed & Insured</div>
              </div>
            </div>
          </div>
        </div>
        <button onClick={prev} aria-label="Previous image" className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-neutral-900/60 hover:bg-neutral-900/80 border border-white/10"><IconChevronLeft className="w-6 h-6"/></button>
        <button onClick={next} aria-label="Next image" className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-neutral-900/60 hover:bg-neutral-900/80 border border-white/10"><IconChevronRight className="w-6 h-6"/></button>
      </div>
    </section>
  );
}

function Services(){
  const items=[
    {icon:"🪚", title:"Wainscoting", desc:"Board-and-batten, picture-frame molding, and feature walls."},
    {icon:"🪟", title:"Windows & Doors", desc:"Casing, sills, and precise jamb installs for a clean finish."},
    {icon:"🗄️", title:"Cabinet Installs & Built-ins", desc:"Pre-built cabinet installs, built-in benches & storage."},
    {icon:"🚪", title:"Barn Doors", desc:"Custom slab builds, stain/finish, and track installs with trim."},
    {icon:"🔥", title:"Fire Mantels", desc:"Custom fireplace mantels and surround trim."},
    {icon:"🛁", title:"Bathroom Remodels", desc:"Vanities, showers, trim, and finishes."},
    {icon:"📐", title:"Baseboards", desc:"Modern or classic profiles with tight inside/outside miters."},
    {icon:"👑", title:"Crown Molding", desc:"Consistent reveals, coped corners, cabinet crown & returns."},
    {icon:"🪜", title:"Staircases", desc:"Newel posts, handrails, iron balusters, skirt boards, landings."},
    {icon:"🔨", title:"Finish Carpentry", desc:"Fireplace mantels, built-ins, and custom details."},
  ];
  const categories = new Set([
    "Wainscoting","Windows & Doors","Baseboards","Crown Molding","Staircases","Cabinet Installs & Built-ins","Barn Doors","Fire Mantels","Bathroom Remodels"
  ]);
  const goToCategory=(title:string)=>{
    const cat = categories.has(title) ? title : "All";
    window.location.hash = cat === "All" ? "#portfolio" : `#portfolio:${encodeURIComponent(cat)}`;
    setTimeout(()=>{ const el=document.getElementById("portfolio"); if(el) el.scrollIntoView({behavior:"smooth"}); }, 160);
  };
  return (
    <section id="services" className="py-20 bg-neutral-950">
      <div className="max-w-6xl mx-auto px-4">
        <SectionTitle eyebrow="What we do" title="Quality trim work that elevates your home" subtitle="Tap a service to see photos in the Portfolio below."/>
        <div className="grid md:grid-cols-3 gap-6">
          {items.map(s => (
            <a key={s.title} href="#portfolio" onClick={(e)=>{e.preventDefault(); goToCategory(s.title);}}
               className="block rounded-2xl border border-white/10 bg-neutral-900/50 p-6 shadow-lg hover:border-emerald-500/50 hover:bg-neutral-900/70 transition-colors cursor-pointer">
              <div className="text-3xl mb-4" aria-hidden>{s.icon}</div>
              <h3 className="text-xl text-white font-semibold">{s.title}</h3>
              <p className="text-gray-400 mt-2">{s.desc}</p>
              <span className="mt-3 inline-block text-sm text-emerald-400">View photos →</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function Portfolio(){
  const [active, setActive] = useState<string>("All");
  const [flash, setFlash] = useState<string | null>(null);
  const flashTimer = useRef<number | null>(null);

  const picks: Record<string, {title: string; sources: string[]}[]> = {
    "Wainscoting": WAINS_PHOTOS,
    "Windows & Doors": WINDOWS_DOORS,
    "Baseboards": BASEBOARD_PHOTOS,
    "Crown Molding": CROWN_MOLDING,
    "Staircases": STAIR_PHOTOS,
    "Cabinet Installs & Built-ins": CABINET_PHOTOS,
    "Barn Doors": BARN_DOOR_PHOTOS,
    "Fire Mantels": FIRE_MANTEL_PHOTOS,
    "Bathroom Remodels": BATHROOM_REMODEL_PHOTOS,
  };

  const TABS = ["All", ...Object.keys(picks)];
  const getList = (key:string) => key === "All" ? Object.values(picks).flat() : (picks[key] || []);

  useEffect(() => {
    const applyFromHash = () => {
      const hash = window.location.hash || "";
      const m = hash.match(/^#portfolio(?::(.+))?$/);
      if (m) {
        const cat = m[1] ? decodeURIComponent(m[1]) : "All";
        if (TABS.includes(cat)) {
          setActive(cat);
          setFlash(cat);
          if (flashTimer.current) window.clearTimeout(flashTimer.current);
          flashTimer.current = window.setTimeout(() => setFlash(null), 2000);
        }
        const el = document.getElementById("portfolio");
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }
    };
    applyFromHash();
    window.addEventListener("hashchange", applyFromHash);
    return () => { window.removeEventListener("hashchange", applyFromHash); if (flashTimer.current) window.clearTimeout(flashTimer.current); };
  }, []);

  const visible = getList(active);

  return (
    <section id="portfolio" className="py-20 bg-neutral-950">
      <div className="max-w-6xl mx-auto px-4">
        <SectionTitle eyebrow="Portfolio" title="Recent Projects" subtitle="Browse by category."/>
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {TABS.map(t => (
            <button key={t} onClick={()=>{ setActive(t); setFlash(null); }} data-flashing={flash===t?"true":undefined}
              className={`px-3 py-1.5 rounded-full text-sm border ${active===t?"bg-emerald-500 text-white border-emerald-500":"border-white/10 text-gray-300 hover:bg-white/5"} ${flash===t?"ring-2 ring-emerald-300 animate-pulse":""}`}>
              {t}
            </button>
          ))}
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((it,i)=>(
            <figure key={(it.title||"item")+i} className="rounded-2xl overflow-hidden border border-white/10 bg-neutral-900/40">
              <SafeImg sources={it.sources} alt={it.title||"Project photo"} className="w-full h-64 object-cover"/>
              {it.title && (<figcaption className="p-3 text-gray-300 text-sm">{it.title}</figcaption>)}
            </figure>
          ))}
          {visible.length===0 && (<p className="text-gray-400 col-span-full text-center">No photos in this category yet.</p>)}
        </div>
      </div>
    </section>
  );
}

function About(){
  return (
    <section id="about" className="py-20 bg-neutral-950">
      <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <SectionTitle eyebrow="About" title="About Design Trim"/>
          <p className="text-gray-300 leading-relaxed">Design Trim is a finish carpentry business with 15 years of experience. We take satisfaction in making sure the job is done right and looks beautiful.</p>
          <p className="text-gray-300 leading-relaxed mt-4">We specialize in trim, pre-built cabinet installs, fireplace mantels, custom barn doors, and staircases.</p>
        </div>
        <div className="rounded-3xl overflow-hidden border border-white/10">
          <img src="https://images.unsplash.com/photo-1519710164239-da123dc03ef4?q=80&w=1600&auto=format&fit=crop" alt="Craftsman at work" className="w-full h-full object-cover"/>
        </div>
      </div>
    </section>
  );
}

function Reviews(){
  return (
    <section id="reviews" className="py-20 bg-neutral-950">
      <div className="max-w-6xl mx-auto px-4">
        <SectionTitle eyebrow="Reviews" title="Homeowners love our work"/>
        <div className="grid md:grid-cols-3 gap-6">
          {[{name:"Samantha R.",text:"Design Trim LLC transformed our living room with beautiful wainscoting and crown. Meticulous work and friendly crew.",stars:5},{name:"Marcus T.",text:"On time, on budget, and the craftsmanship shows. Our stair trim looks amazing!",stars:5},{name:"Linh P.",text:"They rescued a tricky mitered corner project and nailed it. Highly recommend.",stars:5}].map(t => (
            <div key={t.name} className="rounded-2xl border border-white/10 bg-neutral-900/50 p-6">
              <div className="flex items-center gap-1 text-emerald-400" aria-label={`${t.stars} star rating`}>
                {Array.from({length:t.stars}).map((_,i)=>(<IconStar key={i} className="w-4 h-4"/>))}
              </div>
              <p className="text-gray-300 mt-3">“{t.text}”</p>
              <p className="text-gray-400 mt-4 text-sm">— {t.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact(){
  return (
    <section id="contact" className="py-20 bg-neutral-950">
      <div className="max-w-6xl mx-auto px-4">
        <SectionTitle eyebrow="Get a quote" title="Tell us about your project" subtitle={`Serving ${BUSINESS.location}. We usually respond within a business day.`}/>
        <div className="grid md:grid-cols-2 gap-8">
          <form onSubmit={(e)=>{e.preventDefault(); const data=new FormData(e.currentTarget as HTMLFormElement); const subject=encodeURIComponent("Estimate Request – "+BUSINESS.name); const body=encodeURIComponent(`Name: ${data.get("name")}\nEmail: ${data.get("email")}\nPhone: ${data.get("phone")}\nProject: ${data.get("details")}`); window.location.href=`mailto:${BUSINESS.email}?subject=${subject}&body=${body}`; }} className="rounded-2xl border border-white/10 bg-neutral-900/50 p-6">
            <div className="grid grid-cols-1 gap-4">
              <label className="flex flex-col gap-1"><span className="text-sm text-gray-300">Name</span><input name="name" required className="px-3 py-2 rounded-xl bg-neutral-800 text-white border border-white/10"/></label>
              <label className="flex flex-col gap-1"><span className="text-sm text-gray-300">Email</span><input type="email" name="email" required className="px-3 py-2 rounded-xl bg-neutral-800 text-white border border-white/10"/></label>
              <label className="flex flex-col gap-1"><span className="text-sm text-gray-300">Phone</span><input type="tel" name="phone" className="px-3 py-2 rounded-xl bg-neutral-800 text-white border border-white/10"/></label>
              <label className="flex flex-col gap-1"><span className="text-sm text-gray-300">Project Details</span><textarea name="details" rows={5} className="px-3 py-2 rounded-xl bg-neutral-800 text-white border border-white/10" placeholder="Type of trim, rooms, timeline, etc."/></label>
              <button type="submit" className="mt-2 px-5 py-3 rounded-2xl bg-emerald-500 text-white hover:bg-emerald-500/90">Send</button>
            </div>
          </form>
          <div className="rounded-2xl border border-white/10 bg-neutral-900/50 p-6">
            <h3 className="text-white text-xl font-semibold">Contact</h3>
            <div className="mt-4 space-y-3 text-gray-300">
              <p className="flex items-center gap-2"><IconPhone className="w-5 h-5"/> <a href={`tel:${sanitizeDigits(BUSINESS.phone)}`}>{BUSINESS.phone}</a></p>
              <p className="flex items-center gap-2"><IconMessage className="w-5 h-5"/> <a href={`sms:${sanitizeDigits(BUSINESS.phone)}`}>Text Us</a></p>
              <p className="flex items-center gap-2"><IconMail className="w-5 h-5"/> <a href={`mailto:${BUSINESS.email}`}>{BUSINESS.email}</a></p>
              <p className="flex items-center gap-2"><IconMapPin className="w-5 h-5"/> {BUSINESS.location}</p>
            </div>
            <div className="mt-6 p-4 rounded-xl bg-neutral-800/60 text-gray-300">We’re happy to work evenings and weekends by appointment.</div>
            <div className="mt-6 rounded-xl overflow-hidden border border-white/10">
              <SafeImg sources={["/images/received_1278877266060866.jpeg"]} alt={`${BUSINESS.name} banner`} className="w-full h-40 md:h-48 object-cover"/>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer(){
  return (
    <footer className="py-12 border-t border-white/10 bg-neutral-950">
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-gray-400">© {new Date().getFullYear()} {BUSINESS.name}. All rights reserved.</p>
        <p className="text-gray-500 text-sm">Website by {BUSINESS.name} • Licensed & Insured</p>
      </div>
    </footer>
  );
}

function MobileActionBar(){
  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-50">
      <div className="mx-auto max-w-6xl">
        <div className="m-3 rounded-2xl bg-neutral-900/95 border border-white/10 shadow-lg">
          <div className="grid grid-cols-3 divide-x divide-white/10">
            <a href={`tel:${sanitizeDigits(BUSINESS.phone)}`} className="flex items-center justify-center gap-2 py-3 text-white"><span className="text-sm font-medium">Call</span></a>
            <a href={`sms:${sanitizeDigits(BUSINESS.phone)}`} className="flex items-center justify-center gap-2 py-3 text-white"><span className="text-sm font-medium">Text</span></a>
            <a href="#contact" className="flex items-center justify-center gap-2 py-3 text-white"><span className="text-sm font-medium">Get Quote</span></a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function DesignTrimSite(){
  return (
    <div className="min-h-screen bg-neutral-950 text-white pb-16 md:pb-0">
      <Nav/>
      <Hero/>
      <Services/>
      <Portfolio/>
      <About/>
      <Reviews/>
      <Contact/>
      <Footer/>
      <MobileActionBar/>
    </div>
  );
}

/*
====================
Basic Tests (comment)
====================
Use Vitest + RTL as follows:

import { render, screen } from "@testing-library/react";
import DesignTrimSite, { sanitizeDigits, nextIndex, prevIndex } from "./App";

it("sanitizes phone digits", () => {
  expect(sanitizeDigits("(913) 755-1550")).toBe("9137551550");
});

it("carousel index math", () => {
  expect(nextIndex(2,3)).toBe(0);
  expect(prevIndex(0,3)).toBe(2);
});

it("services redirects to portfolio via hash", () => {
  window.location.hash="";
  render(<DesignTrimSite/>);
  screen.getByText(/Baseboards/i).click();
  expect(window.location.hash).toBe('#portfolio:Baseboards');
});
*/
